package com.training.employeeaccountapp.service;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import com.training.employeeaccountapp.model.Employee;


@FeignClient(value = "empApp", url = "http://localhost:5555/employee")
public interface EmployeeService {
	
	@PostMapping("")
	public Employee createEmployee(@RequestBody Employee e);
	@PutMapping("")
	public Employee updateEmployee(@RequestBody Employee e);
	@DeleteMapping("")
	public boolean deleteEmployee(@RequestParam int id);
	@GetMapping("")
	public Employee getEmployee(@RequestParam int id);
	@GetMapping("/all")
	public List<Employee> getEmployees();
}
