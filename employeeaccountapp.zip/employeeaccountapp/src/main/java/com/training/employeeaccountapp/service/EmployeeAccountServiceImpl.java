package com.training.employeeaccountapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.employeeaccountapp.model.Employee;

@Service
public class EmployeeAccountServiceImpl implements EmployeeAccountService {
	@Autowired
	EmployeeService empService;
	@Autowired
	AccountService accService;

	@Override
	public List<Employee> getEmployees() {
		List<Employee> empList = empService.getEmployees();
		empList.forEach(e->e.setAccountList(accService.getAccounts(e.getId())));
		return empList;
	}

	@Override
	public Employee createEmployee(Employee e) {
		Employee e1 = empService.createEmployee(e);

		e1.getAccountList().forEach(a->{
			a.setEmpId(e1.getId());
			accService.createAccount(a);
		});
		return e;
	}

}
