package com.training.employeeaccountapp.service;

import java.util.List;

import com.training.employeeaccountapp.model.Employee;

public interface EmployeeAccountService {
	public List<Employee> getEmployees();
	public Employee createEmployee(Employee e);
}
