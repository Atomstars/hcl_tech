package com.training.employeeaccountapp.model;

import java.time.LocalDate;
import java.util.List;

import javax.validation.constraints.Min;
import javax.validation.constraints.Past;

import org.hibernate.validator.constraints.Length;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Employee {
	private Integer id;
	@Length(min = 4)
	private String name;
	@Min(value = 21)
	private int age;
	@Min(value = 1)
	private double salary;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy/MM/dd")
	@Past
	private LocalDate dateOfBirth;
	private List<Account> accountList;
}
