package com.training.employeeaccountapp.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Account {
	private int id;
	private String accountNumber;
	private char accountType;
	private double balance;
	private String bankName;
	private int empId;
}
