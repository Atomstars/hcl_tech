package com.training.employeeaccountapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.training.employeeaccountapp.model.Employee;
import com.training.employeeaccountapp.service.EmployeeAccountService;

@RestController // ResponseBody + Controller
@RequestMapping("/employeeAccounts") // http://localhost:5555/employee
public class EmployeeAccountController {
	@Autowired
	EmployeeAccountService empAccService;
	
	@GetMapping("/all")
	public List<Employee> getEmployees()
	{
		return empAccService.getEmployees();
	}
	
	@PostMapping("")
	public Employee createEmployee(@RequestBody Employee e) {
		return empAccService.createEmployee(e);
	}
	
}
