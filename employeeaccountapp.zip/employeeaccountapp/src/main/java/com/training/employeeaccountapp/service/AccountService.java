package com.training.employeeaccountapp.service;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import com.training.employeeaccountapp.model.Account;

@FeignClient(value = "accApp", url = "http://localhost:6666/account")
public interface AccountService {
	@GetMapping("")
	public List<Account> getAccounts(@RequestParam int empId);
	@PostMapping("")
	public Account createAccount(@RequestBody Account acc);
	@PutMapping("")
	public Account updateAccount(@RequestBody Account acc);
	@DeleteMapping("")
	public boolean deleteAccount(@RequestParam int id);
}
